﻿var currenturl;
var record = sessionStorage;
var status = false;

chrome.contextMenus.create({
    title: "Start BugScan",
    id: "BugScan",
    onclick: function(){
        if (status == 'true') {
            chrome.contextMenus.update('BugScan', {title: 'Start BugScan'} , function(){});
            status = false;
        }else{
            chrome.contextMenus.update('BugScan', {title: 'Stop BugScan'} , function(){});
            status = true;
        }
    }
});


chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab){
    if (status != 'true') {
        return;
    }
    if(changeInfo.status == "loading"){
    	updateIcon("icon16");
      if (tab.url.substr(0, 6) != 'chrome' && tab.url.substr(0, 11) != 'view-source' && tab.url.substr(0, 4) != 'file') {
          startScan(tab.url);
      }
    }
});


function parseURL(url) { 
	var a = document.createElement('a'); 
	a.href = url; 
	return { 
	    source: url, 
	    protocol: a.protocol.replace(':', ''), 
	    host: a.hostname, 
		  port: a.port, 
		  query: a.search, 
		  params: (function(){ 
			    var ret = {}, 
			    seg = a.search.replace(/^\?/, '').split('&'), 
			    len = seg.length, i = 0, s; 
			    for (; i < len; i++) { 
				      if (!seg[i]) { continue; } 
			    s = seg[i].split('='); 
		      ret[s[0]] = s[1]; 
	        }
		      return ret; 
	   })(),

	    file: (a.pathname.match(/\/([^\/?#]+)$/i) || [,''])[1], 
	    hash: a.hash.replace('#',''), 
	    path: a.pathname.replace(/^([^\/])/,'/$1'), 
	    relative: (a.href.match(/tps?:\/\/[^\/]+(.+)/) || [,''])[1], 
	    segments: a.pathname.replace(/^\//,'').split('/') 
	}; 
}


//update icon
function updateIcon(name) {
  chrome.browserAction.setIcon({path: "image/" + name + ".png"});
}

function copyTextToClipboard(text) {
    var textArea = document.createElement("textarea")

    textArea.style.position = 'fixed'
    textArea.style.top = 0
    textArea.style.left = 0
    textArea.style.width = '2em'
    textArea.style.height = '2em'
    textArea.style.padding = 0
    textArea.style.border = 'none'
    textArea.style.outline = 'none'
    textArea.style.boxShadow = 'none'
    textArea.style.background = 'transparent'
    textArea.value = text

    document.body.appendChild(textArea)

    textArea.select()

    try {
      var msg = document.execCommand('copy') ? 'sucess' : 'failed'
      // console.log('复制内容 ' + msg)
    } catch (err) {
      console.log('不能使用这种方法复制内容')
    }

    document.body.removeChild(textArea)
}


function show(title, content, tagname) {
  localStorage.setItem(new Date().getTime(), content);
  var notice = new Notification(title, {
    body: content,
    icon: "image/icon48.png",
    tag: tagname, // 可以加一个tag
  });
  
  // notice['onclose'] = function(event){
  //     window.open(content, '_blank');
  // };
  notice['onclick'] = function(event){
      copyTextToClipboard(content);
  };
}


function gitfinder(protocol, host, port, path){
  var giturl = protocol + "://" + host + path + ".git/config";
    if(port){
      giturl = protocol + "://" + host + ":" + port + path + ".git/config";
    }
   $.ajax({
      type: "GET",
      url : giturl,
      complete: function(xmlhttp) { 
        if (xmlhttp.readyState == 4) { 
          if (xmlhttp.status == 200) {  
                var responseText = xmlhttp.responseText;
                if(responseText){
                  var match = responseText.match(/repository/i);
                  var match2 = responseText.match(/DOCTYPE/i);
                    if(match && !match2){
                      updateIcon("fire");
                      show("Git Leak", giturl, giturl);
                    }
                }
            }
        }
      },
  });
}


function svnfinder(protocol, host, port, path){
	var svnurl = protocol + "://" + host + path + ".svn/entries";
    if(port){
      svnurl = protocol + "://" + host + ":" + port + path + ".svn/entries";
    }
   $.ajax({
      type: "GET",
      url : svnurl,
      complete: function(xmlhttp) { 
				//完成交互
				if (xmlhttp.readyState == 4) { 
				 		//状态码
          if (xmlhttp.status == 200) {  
                // var ct=xmlhttp.getResponseHeader("Connection");
                // var cct= "close";
                var responseText = xmlhttp.responseText;
                if(responseText){
                	var match1 = responseText.match(/svn/i);
                  var match2 = responseText.match(/dir/i);
                  var match3 = responseText.match(/DOCTYPE/i);
        						if(match1 && match2 && !match3){
        							updateIcon("fire");
        							show("Svn Leak", svnurl, svnurl);
        						}
                }
            } 
			   }
			},
  });
}

//find .DS_Store file
function ds_storefinder(protocol, host, port, path){
  var ds_storeurl =protocol + "://" + host + path + ".DS_Store";
  if(port){
    ds_storeurl =protocol + "://" + host + ":" + port + path + ".DS_Store";
  }

  $.ajax({
      type: "HEAD",
      url : ds_storeurl,
      complete: function(xmlhttp) { 
        //完成交互
        if (xmlhttp.readyState == 4) { 
            //状态码
          if (xmlhttp.status == 200) {  
                var ct=xmlhttp.getResponseHeader("Content-Type");
                if(ct == "application/octet-stream"){
                    updateIcon("fire");
                    show("A .DS_Store file find", ds_storeurl, ds_storeurl);
                }
            }
        }
      },
  });
}

//find .env file
function envfinder(protocol, host, port, path){
  var envurl =protocol + "://" + host + path + ".env";
  if(port){
    envurl =protocol + "://" + host + ":" + port + path + ".env";
  }

  $.ajax({
      type: "GET",
      url : envurl,
      complete: function(xmlhttp) { 
        //完成交互
        if (xmlhttp.readyState == 4) { 
            //状态码
          if (xmlhttp.status == 200) {  
                var responseText = xmlhttp.responseText;
                if(responseText){
					console.log(responseText);
                	var match1 = responseText.match(/APP_ENV/);
					var match2 = responseText.match(/APP_KEY/);
					var match3 = responseText.match(/DB_HOST/);
					if(match1 || match2 || match3){
						updateIcon("fire");
						show("A .env file find", envurl, envurl);
					}
                }
            }
        }
      },
  });
}

//find bash history file
function bash(protocol, host, port, path){
	var bashurl =protocol + "://" + host + path + ".bash_history";
  if(port){
    bashurl =protocol + "://" + host + ":" + port + path + ".bash_history";
  }
  $.ajax({
        type: "GET",
        url: bashurl,
        complete: function(xmlhttp) { 
				//完成交互
				 if (xmlhttp.readyState == 4) { 
				 		if (xmlhttp.status == 200) {  
             	var responseText = xmlhttp.responseText;
            	var match = responseText.match(/((cd)\s\w*\/)|(vi\s\w*\.\w*)/i);
              var match3 = responseText.match(/DOCTYPE/i);
  						if(match && !match3){
  							updateIcon("fire");
  							show("Bash History Leak", bashurl, bashurl);
  						}
            } 
				 }
		  },
  });
}


//find id_rsa file
function idrsa(protocol, host, port, path){
	var idrsaurl =protocol + "://" + host + path + "id_rsa";
  if(port){
    idrsaurl =protocol + "://" + host + ":" + port + path + "id_rsa";
  }
  $.ajax({
        type: "GET",
        url: idrsaurl,
        complete: function(xmlhttp) { 
				//完成交互
				 if (xmlhttp.readyState == 4) { 
				 		if (xmlhttp.status == 200) {  
             	var responseText = xmlhttp.responseText;
            	var match = responseText.match(/BEGIN/i);
  						if(match){
  							updateIcon("fire");
  							show("id_rsa Leak", idrsaurl, idrsaurl);
  						}
            } 
				 }
		  },
  });
}
//find id_rsa file
function idrsa1(protocol, host, port, path){
	var idrsa_url =protocol + "://" + host + path + ".ssh/id_rsa";
  if(port){
    idrsa_url =protocol + "://" + host + ":" + port + path + ".ssh/id_rsa";
  }
  $.ajax({
        type: "GET",
        url: idrsa_url,
        complete: function(xmlhttp) { 
				//完成交互
				 if (xmlhttp.readyState == 4) { 
				 		if (xmlhttp.status == 200) {  
             	var responseText = xmlhttp.responseText;
            	var match = responseText.match(/BEGIN/i);
  						if(match){
  							updateIcon("fire");
  							show("id_rsa Leak", idrsa_url, idrsa_url);
  						}
            } 
				 }
		  },
  });
}

//find id_dsa file
function iddsa(protocol, host, port, path){
	var iddsaurl =protocol + "://" + host + path + "id_dsa";
  if(port){
    iddsaurl =protocol + "://" + host + ":" + port + path + "id_dsa";
  }
  $.ajax({
        type: "GET",
        url: iddsaurl,
        complete: function(xmlhttp) { 
				//完成交互
				 if (xmlhttp.readyState == 4) { 
				 		if (xmlhttp.status == 200) {  
             	var responseText = xmlhttp.responseText;
            	var match = responseText.match(/BEGIN/i);
  						if(match){
  							updateIcon("fire");
  							show("id_dsa Leak", iddsaurl, iddsaurl);
  						}
            } 
				 }
		  },
  });
}
//find id_dsa file
function iddsa1(protocol, host, port, path){
	var iddsa_url =protocol + "://" + host + path + ".ssh/id_dsa";
  if(port){
    iddsa_url =protocol + "://" + host + ":" + port + path + ".ssh/id_dsa";
  }
  $.ajax({
        type: "GET",
        url: iddsa_url,
        complete: function(xmlhttp) { 
				//完成交互
				 if (xmlhttp.readyState == 4) { 
				 		if (xmlhttp.status == 200) {  
             	var responseText = xmlhttp.responseText;
            	var match = responseText.match(/BEGIN/i);
  						if(match){
  							updateIcon("fire");
  							show("id_dsa Leak", iddsa_url, iddsa_url);
  						}
            } 
				 }
		  },
  });
}
//find zip backup file
function backupfinder_zip(protocol, host, port, path, filename){
  var backupURL_zip =protocol + "://" + host + path + filename + ".zip";
  if(port){
    backupURL_zip =protocol + "://" + host + ":" + port + path + filename + ".zip";
  }

  $.ajax({
      type: "HEAD",
      url : backupURL_zip,
      complete: function(xmlhttp) { 
        //完成交互
        if (xmlhttp.readyState == 4) { 
            //状态码
          if (xmlhttp.status == 200) {  
                var ct=xmlhttp.getResponseHeader("Content-Type");
                if(ct == "application/zip" || ct == "application/x-zip-compressed"){
                    updateIcon("fire");
                    show("Maybe a backup file find", backupURL_zip, backupURL_zip);
                }
            }
        }
      },
  });
}

//find tar.gz backup file
function backupfinder_tar_gz(protocol, host, port, path, filename){
  var backupURL_gz =protocol + "://" + host + path + filename + ".tar.gz";
  if(port){
    backupURL_gz =protocol + "://" + host + ":" + port + path + filename + ".tar.gz";
  }

  $.ajax({
      type: "HEAD",
      url : backupURL_gz,
      complete: function(xmlhttp) { 
        //完成交互
        if (xmlhttp.readyState == 4) { 
            //状态码
          if (xmlhttp.status == 200) {  
                var ct=xmlhttp.getResponseHeader("Content-Type");
                if(ct == "application/octet-stream"){
                    updateIcon("fire");
                    show("Maybe a backup file find", backupURL_gz, backupURL_gz);
                }
            }
        }
      },
  });
}

//find rar backup file
function backupfinder_rar(protocol, host, port, path, filename){
  var backupURL_rar =protocol + "://" + host + path + filename + ".rar";
  if(port){
    backupURL_rar =protocol + "://" + host + ":" + port + path + filename + ".rar";
  }

  $.ajax({
      type: "HEAD",
      url : backupURL_rar,
      complete: function(xmlhttp) { 
        //完成交互
        if (xmlhttp.readyState == 4) { 
            //状态码
          if (xmlhttp.status == 200) {  
                var ct=xmlhttp.getResponseHeader("Content-Type");
                if(ct == "application/x-rar-compressed"){
                    updateIcon("fire");
                    show("Maybe a backup file find", backupURL_rar, backupURL_rar);
                }
            }
        }
      },
  });
}

//check phpinfo
function phpinfoFinder(protocol, host, port, path, filename){
  var phpinfourl =protocol + "://" + host + path + filename + ".php";
  if(port){
    phpinfourl =protocol + "://" + host + ":" + port + path + filename + ".php";
  }

  $.ajax({
      type: "GET",
      url : phpinfourl,
      complete: function(xmlhttp) { 
        //完成交互
        if (xmlhttp.readyState == 4) {
            //状态码
          if (xmlhttp.status == 200) {  
              var responseText = xmlhttp.responseText;
              var match1 = responseText.match(/phpinfo/);
              var match2 = responseText.match(/Zend/);
              if(match1 && match2){
                updateIcon("fire");
                //alert(phpinfourl);
                show("A phpinfo file find", phpinfourl, phpinfourl);
              }
            }
        }
      },
  });
}


//check idea
function ideaFinder(protocol, host, port, path){
  var ideaurl =protocol + "://" + host + path  + ".idea/workspace.xml";
  if(port){
    ideaurl =protocol + "://" + host + ":" + port + path + ".idea/workspace.xml";
  }

  $.ajax({
      type: "GET",
      url : ideaurl,
      complete: function(xmlhttp) { 
        //完成交互
        if (xmlhttp.readyState == 4) {
            //状态码
          if (xmlhttp.status == 200) {  
              var responseText = xmlhttp.responseText;
              var match1 = responseText.match(/project /);
              var match2 = responseText.match(/component /);
              if(match1 && match2){
                updateIcon("fire");
                //alert(ideaurl);
                show("A .idea file find", ideaurl, ideaurl);
              }
            }
        }
      },
  });
}


//check sftp
function sftp(protocol, host, port, path){
	var sftpurl =protocol + "://" + host + path + "sftp-config.json";
  if(port){
    sftpurl =protocol + "://" + host + ":" + port + path + "sftp-config.json";
  }
  $.ajax({
        type: "GET",
        url: sftpurl,
        complete: function(xmlhttp) { 
				//完成交互
				 if (xmlhttp.readyState == 4) { 
				 		if (xmlhttp.status == 200) {  
                var ct=xmlhttp.getResponseHeader("Content-Type");
                if(ct == "application/json"){
                    updateIcon("fire");
                    show("ftp config find", sftpurl, sftpurl);
                }
            } 
				 }
		  },
  });
}


function svnfinder(protocol, host, port, path){
	var svnurl = protocol + "://" + host + path + ".svn/entries";
    if(port){
      svnurl = protocol + "://" + host + ":" + port + path + ".svn/entries";
    }
   $.ajax({
      type: "GET",
      url : svnurl,
      complete: function(xmlhttp) { 
				//完成交互
				if (xmlhttp.readyState == 4) { 
				 		//状态码
          if (xmlhttp.status == 200) {  
                // var ct=xmlhttp.getResponseHeader("Connection");
                // var cct= "close";
                var responseText = xmlhttp.responseText;
                if(responseText){
                	var match1 = responseText.match(/svn/i);
                  var match2 = responseText.match(/dir/i);
                  var match3 = responseText.match(/DOCTYPE/i);
        						if(match1 && match2 && !match3){
        							updateIcon("fire");
        							show("Svn Leak", svnurl, svnurl);
        						}
                }
            } 
			   }
			},
  });
}

// druid-monitor-unauth
function druidfinder(protocol, host, port, path){
	var druidurl = protocol + "://" + host + path + "druid/basic.json";
    if(port){
      druidurl = protocol + "://" + host + ":" + port + path + "druid/basic.json";
    }
   $.ajax({
      type: "GET",
      url : druidurl,
      complete: function(xmlhttp) { 
				//完成交互
				if (xmlhttp.readyState == 4) { 
				 		//状态码
          if (xmlhttp.status == 200) {  

                var responseText = xmlhttp.responseText;
                if(responseText){
                	var match1 = responseText.match(/ResultCode/);
                  var match2 = responseText.match(/DruidDriver/);
        						if(match1 && match2){
        							updateIcon("fire");
        							show("druid-monitor-unauth Leak", druidurl, druidurl);
        						}
                }
            } 
			   }
			},
  });
}

//check phpmyadmin
function phpmyadmin(protocol, host, port, path){
  var phpmyadminurl = protocol + "://" + host + path + "index.php";
  if(port){
    phpmyadminurl = protocol + "://" + host + ":" + port + path + "index.php";
  }

  $.ajax({
      type: "GET",
      url : phpmyadminurl,
      complete: function(xmlhttp) { 
        if (xmlhttp.readyState == 4) {
          if (xmlhttp.status == 200) {  
              var responseText = xmlhttp.responseText;
              var match1 = responseText.match(/phpMyAdmin/);
              var match2 = responseText.match(/English/);
              if(match1 && match2){
                updateIcon("fire");
                show("phpMyAdmin find", phpmyadminurl, phpmyadminurl);
              }
            }
        }
      },
  });
}

//check /resin-doc/resource/tutorial/jndi-appconfig/test?inputFile=/etc/passwd
/* function resinfinder(protocol, host, port, path){
  var resinurl =protocol + "://" + host + path  + "resin-doc/resource/tutorial/jndi-appconfig/test?inputFile=/etc/passwd";
  if(port){
    resinurl =protocol + "://" + host + ":" + port + path + "resin-doc/resource/tutorial/jndi-appconfig/test?inputFile=/etc/passwd";
  }

  $.ajax({
      type: "GET",
      url : resinurl,
      complete: function(xmlhttp) { 
        //完成交互
        if (xmlhttp.readyState == 4) {
            //状态码
          if (xmlhttp.status == 200) {  
              var responseText = xmlhttp.responseText;
              var match1 = responseText.match(/root:x: /);
              var match2 = responseText.match(/inputFile /);
              if(match1 && match2){
                updateIcon("fire");
                //alert(ideaurl);
                show("Resin fileread vuln", resinurl, resinurl);
              }
            }
        }
      },
  });
} */

//check Zabbix jsrpc.php SQLi
/* function zabbixfinder(protocol, host, port, path){
  var zabbixnurl =protocol + "://" + host + path  + "jsrpc.php?sid=0bcd4ade648214dc&type=9&method=screen.get&tamp=1471403798083&mode=2&screenid=&groupid=&hostid=0&pageFile=history.php&profileIdx=web.item.graph&profileIdx2=1zabbix/jsrpc.php?sid=0bcd4ade648214dc&type=9&method=screen.get&tim%20estamp=1471403798083&mode=2&screenid=&groupid=&hostid=0&pageFile=hi%20story.php&profileIdx=web.item.graph&profileIdx2=(select%201%20from%20(select%20count(*),concat(floor(rand(0)*2),%20user())x%20from%20information_schema.character_sets%20group%20by%20x)y)&updateProfil%20e=true&screenitemid=&period=3600&stime=20160817050632&resourcetype=%2017&itemids%5B23297%5D=23297&action=showlatest&filter=&filter_task=&%20mark_color=1";
  if(port){
    zabbixnurl =protocol + "://" + host + ":" + port + path + "jsrpc.php?sid=0bcd4ade648214dc&type=9&method=screen.get&tamp=1471403798083&mode=2&screenid=&groupid=&hostid=0&pageFile=history.php&profileIdx=web.item.graph&profileIdx2=1zabbix/jsrpc.php?sid=0bcd4ade648214dc&type=9&method=screen.get&tim%20estamp=1471403798083&mode=2&screenid=&groupid=&hostid=0&pageFile=hi%20story.php&profileIdx=web.item.graph&profileIdx2=(select%201%20from%20(select%20count(*),concat(floor(rand(0)*2),%20user())x%20from%20information_schema.character_sets%20group%20by%20x)y)&updateProfil%20e=true&screenitemid=&period=3600&stime=20160817050632&resourcetype=%2017&itemids%5B23297%5D=23297&action=showlatest&filter=&filter_task=&%20mark_color=1";
  }

  $.ajax({
      type: "GET",
      url : zabbixnurl,
      complete: function(xmlhttp) { 
        //完成交互
        if (xmlhttp.readyState == 4) {
            //状态码
          if (xmlhttp.status == 200) {  
              var responseText = xmlhttp.responseText;
              var match1 = responseText.match(/Duplicate entry /);
              if(match1){
                updateIcon("fire");
                // alert(zabbixnurl);
                show("Zabbix jsrpc.php SQLi", zabbixnurl, zabbixnurl);
              }
            }
        }
      },
  });
}

//check Zabbix jsrpc.php SQLi
function zabbix1finder(protocol, host, port, path){
  var zabbixnurl =protocol + "://" + host + path  + "zabbix/jsrpc.php?sid=0bcd4ade648214dc&type=9&method=screen.get&tamp=1471403798083&mode=2&screenid=&groupid=&hostid=0&pageFile=history.php&profileIdx=web.item.graph&profileIdx2=1zabbix/jsrpc.php?sid=0bcd4ade648214dc&type=9&method=screen.get&tim%20estamp=1471403798083&mode=2&screenid=&groupid=&hostid=0&pageFile=hi%20story.php&profileIdx=web.item.graph&profileIdx2=(select%201%20from%20(select%20count(*),concat(floor(rand(0)*2),%20user())x%20from%20information_schema.character_sets%20group%20by%20x)y)&updateProfil%20e=true&screenitemid=&period=3600&stime=20160817050632&resourcetype=%2017&itemids%5B23297%5D=23297&action=showlatest&filter=&filter_task=&%20mark_color=1";
  if(port){
    zabbixnurl =protocol + "://" + host + ":" + port + path + "zabbix/jsrpc.php?sid=0bcd4ade648214dc&type=9&method=screen.get&tamp=1471403798083&mode=2&screenid=&groupid=&hostid=0&pageFile=history.php&profileIdx=web.item.graph&profileIdx2=1zabbix/jsrpc.php?sid=0bcd4ade648214dc&type=9&method=screen.get&tim%20estamp=1471403798083&mode=2&screenid=&groupid=&hostid=0&pageFile=hi%20story.php&profileIdx=web.item.graph&profileIdx2=(select%201%20from%20(select%20count(*),concat(floor(rand(0)*2),%20user())x%20from%20information_schema.character_sets%20group%20by%20x)y)&updateProfil%20e=true&screenitemid=&period=3600&stime=20160817050632&resourcetype=%2017&itemids%5B23297%5D=23297&action=showlatest&filter=&filter_task=&%20mark_color=1";
  }

  $.ajax({
      type: "GET",
      url : zabbixnurl,
      complete: function(xmlhttp) { 
        //完成交互
        if (xmlhttp.readyState == 4) {
            //状态码
          if (xmlhttp.status == 200) {  
              var responseText = xmlhttp.responseText;
              var match1 = responseText.match(/Duplicate entry /);
              if(match1){
                updateIcon("fire");
                // alert(zabbixnurl);
                show("Zabbix jsrpc.php SQLi", zabbixnurl, zabbixnurl);
              }
            }
        }
      },
  });
} */

//springboot-env-unauth
function springbootfinder(protocol, host, port, path){
	var springbooturl = protocol + "://" + host + path + "actuator/env";
    if(port){
      springbooturl = protocol + "://" + host + ":" + port + path + "actuator/env";
    }
   $.ajax({
      type: "GET",
      url : springbooturl,
      complete: function(xmlhttp) { 
				//完成交互
				if (xmlhttp.readyState == 4) { 
				 		//状态码
          if (xmlhttp.status == 200) {  

                var responseText = xmlhttp.responseText;
                if(responseText){
                	var match1 = responseText.match(/activeProfiles/);
                  var match2 = responseText.match(/defaultProperties/);
        						if(match1 && match2){
        							updateIcon("fire");
        							show("springboot-env-unauth Leak", springbooturl, springbooturl);
        						}
                }
            } 
			   }
			},
  });
}

//springboot-env-unauth 1
function springboot1finder(protocol, host, port, path){
	var springboot1url = protocol + "://" + host + path + "env";
    if(port){
      springboot1url = protocol + "://" + host + ":" + port + path + "env";
    }
   $.ajax({
      type: "GET",
      url : springboot1url,
      complete: function(xmlhttp) { 
				//完成交互
				if (xmlhttp.readyState == 4) { 
				 		//状态码
          if (xmlhttp.status == 200) {  

                var responseText = xmlhttp.responseText;
                if(responseText){
                	var match1 = responseText.match(/activeProfiles/);
                  var match2 = responseText.match(/defaultProperties/);
        						if(match1 && match2){
        							updateIcon("fire");
        							show("springboot-env-unauth Leak", springboot1url, springboot1url);
        						}
                }
            } 
			   }
			},
  });
}

function setStorage(protocol, host, port, path){
    if (port) {
        var idx = protocol + "://" + host + ':' + port + path;
    } else {
        var idx = protocol + "://" + host + path;
    }
    record.setItem(idx, true);
}


function getStorage(protocol, host, port, path){
    if (port) {
        var idx =protocol + "://" + host + ':' + port + path;
    } else {
        var idx = protocol + "://" +  host + path;
    }
    // return false;	//去掉刷新判断    
    if (record.getItem(idx)) {
      return true;
    }else{
      return false;
    }
}


function getPathName(path, file){
    tmp_path = path.replace(file,"").split('/');
    tmp_path.splice(0,1);
    return tmp_path;
}


function leakFileFind(protocol,host, port, path){
    //文件泄露
    //phpinfo文件
    var phpinfoFilenameArr = new Array('1', 'php', 'phpinfo', 'test', 'info', 'l', 'i', 'u', 'tz', 'p', 'iProber2', 'upload', 'download');
    if (!getStorage(protocol,host, port, path)) {
          bash(protocol,host,port,path);
		  sftp(protocol,host,port,path);
          gitfinder(protocol,host, port, path);
          svnfinder(protocol,host,port,path);
          ds_storefinder(protocol,host, port, path);
		  envfinder(protocol,host, port, path);
		  // resinfinder(protocol,host, port, path);
/* 		  zabbixfinder(protocol,host, port, path);
		  zabbix1finder(protocol,host, port, path); */
          for (var j = phpinfoFilenameArr.length - 1; j >= 0; j--) {
              phpinfoFinder(protocol, host, port, path, phpinfoFilenameArr[j]);
      
          }
          phpmyadmin(protocol, host, port, path + 'phpMyAdmin/');
          phpmyadmin(protocol, host, port, path + 'phpmyadmin/');
          phpmyadmin(protocol, host, port, path + 'pmd/');
          phpmyadmin(protocol, host, port, path + 'phpMyadmin/');
          ideaFinder(protocol, host, port, path);
		  druidfinder(protocol,host, port, path);
		  springbootfinder(protocol,host, port, path);
		  springboot1finder(protocol,host, port, path);
          setStorage(protocol,host, port, path);
		  idrsa(protocol,host, port, path);
		  idrsa1(protocol,host, port, path);
		  iddsa(protocol,host, port, path);
		  iddsa1(protocol,host, port, path);
     }
}


function backupfileFind(protocol, host, port, path, OnlyPathName) {
    //备份文件
    var backFilenameArr = new Array('backup', 'www', '2018', '2019','2020', 'back', 'upload', '1', 'public','wwwroot', 'web', 'data', 'sql')
    if (!getStorage(protocol, host, port, path + 'backupFind')) {
      for (var i = backFilenameArr.length - 1; i >= 0; i--) {
        backupfinder_zip(protocol, host, port, path, backFilenameArr[i]);
        backupfinder_tar_gz(protocol, host, port, path, backFilenameArr[i]);
		backupfinder_rar(protocol, host, port, path, backFilenameArr[i]);

      }
      backupfinder_zip(protocol, host, port, path, '../' + OnlyPathName);
      backupfinder_tar_gz(protocol, host, port, path, '../' + OnlyPathName);
	  backupfinder_rar(protocol, host, port, path, '../' + OnlyPathName);
      setStorage(protocol, host, port, path + 'backupFind');
    }
}

function startScan(url) {
    var parsedURL = parseURL(url);
    var protocol = parsedURL.protocol;
    var host = parsedURL.host;
    var port = parsedURL.port;
    var path = parsedURL.path;
    var file = parsedURL.file;

    pathAry = getPathName(path, file);
    //
    if (pathAry.length == 1) {
        //没有子目录
        leakFileFind(protocol, host, port, '/');
        backupfileFind(protocol, host, port, '/', host);
    } else if(pathAry.length > 1 && pathAry[0] != '.git' && pathAry[0] != '.svn'){
        //探测一级目录
        leakFileFind(protocol, host, port, '/');
        leakFileFind(protocol, host, port, '/' + pathAry[0] + '/');
        backupfileFind(protocol, host, port, '/', host);
        backupfileFind(protocol, host, port, '/' + pathAry[0] + '/', pathAry[0]);
        //探测二级目录
        if (pathAry[1]) {
            leakFileFind(protocol, host, port, '/' + pathAry[0] + '/' + pathAry[1] + '/');
            backupfileFind(protocol, host, port, '/' + pathAry[0] + '/' + pathAry[1] + '/', pathAry[1]);
        }
    }
}